<?php

namespace Imperio\Controllers;

use Config\Base\Basecontrolador;

class Painel extends Basecontrolador
{
    public function listar()
    {
        echo "Painel::listar executado automaticamente!";
    }
}
